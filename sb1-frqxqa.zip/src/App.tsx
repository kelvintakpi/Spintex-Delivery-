import React, { Suspense } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
const Services = React.lazy(() => import('./components/Services'));
const TrackingSection = React.lazy(() => import('./components/TrackingSection'));
const Contact = React.lazy(() => import('./components/Contact'));
const Footer = React.lazy(() => import('./components/Footer'));

function LoadingSpinner() {
  return (
    <div className="flex items-center justify-center p-8">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
    </div>
  );
}

function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <Hero />
      <Suspense fallback={<LoadingSpinner />}>
        <Services />
        <TrackingSection />
        <Contact />
        <Footer />
      </Suspense>
    </div>
  );
}

export default App;