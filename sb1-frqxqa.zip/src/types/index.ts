export interface TrackingResult {
  status: 'pending' | 'in-transit' | 'delivered';
  location?: string;
  timestamp?: string;
  details?: string;
}

export interface ContactForm {
  firstName: string;
  lastName: string;
  email: string;
  message: string;
}