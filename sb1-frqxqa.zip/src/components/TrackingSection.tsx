import React, { useState } from 'react';
import { Search, Package, AlertCircle } from 'lucide-react';
import type { TrackingResult } from '../types';

export default function TrackingSection() {
  const [trackingNumber, setTrackingNumber] = useState('');
  const [result, setResult] = useState<TrackingResult | null>(null);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setResult(null);

    if (!trackingNumber.trim()) {
      setError('Please enter a tracking number');
      return;
    }

    // Simulate API call with mock data
    try {
      // In production, this would be a real API call
      const mockResult: TrackingResult = {
        status: 'in-transit',
        location: 'Chicago Distribution Center',
        timestamp: new Date().toISOString(),
        details: 'Package is being processed for delivery',
      };
      setResult(mockResult);
    } catch (err) {
      setError('Unable to fetch tracking information. Please try again.');
    }
  };

  return (
    <section id="tracking" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Track Your Package</h2>
          <p className="text-xl text-gray-600 mb-8">Enter your tracking number to get real-time updates</p>

          <form onSubmit={handleSubmit} className="flex flex-col md:flex-row gap-4">
            <input
              type="text"
              value={trackingNumber}
              onChange={(e) => setTrackingNumber(e.target.value)}
              placeholder="Enter tracking number"
              className="flex-1 px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button
              type="submit"
              className="bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 flex items-center justify-center"
            >
              <Search className="h-5 w-5 mr-2" />
              Track Now
            </button>
          </form>

          {error && (
            <div className="mt-4 p-4 bg-red-50 text-red-700 rounded-md flex items-center">
              <AlertCircle className="h-5 w-5 mr-2" />
              {error}
            </div>
          )}

          {result && (
            <div className="mt-8 bg-white p-6 rounded-lg shadow-lg">
              <div className="flex items-center justify-center mb-4">
                <Package className="h-8 w-8 text-blue-600 mr-2" />
                <h3 className="text-xl font-semibold">Tracking Details</h3>
              </div>
              <div className="space-y-4">
                <div className="flex justify-between py-2 border-b">
                  <span className="font-medium">Status:</span>
                  <span className="text-blue-600 capitalize">{result.status}</span>
                </div>
                <div className="flex justify-between py-2 border-b">
                  <span className="font-medium">Location:</span>
                  <span>{result.location}</span>
                </div>
                <div className="flex justify-between py-2 border-b">
                  <span className="font-medium">Last Updated:</span>
                  <span>{new Date(result.timestamp!).toLocaleString()}</span>
                </div>
                <div className="py-2">
                  <span className="font-medium">Details:</span>
                  <p className="mt-1 text-gray-600">{result.details}</p>
                </div>
              </div>
            </div>
          )}

          <div className="mt-12 grid md:grid-cols-3 gap-8">
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="font-semibold mb-2">Fast Tracking</h3>
              <p className="text-gray-600">Real-time updates on your package location</p>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="font-semibold mb-2">Detailed History</h3>
              <p className="text-gray-600">Complete timeline of your shipment journey</p>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="font-semibold mb-2">SMS Updates</h3>
              <p className="text-gray-600">Get notifications directly to your phone</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}