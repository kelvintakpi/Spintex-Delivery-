import React from 'react';
import { ArrowRight, Package, Clock, Globe } from 'lucide-react';

export default function Hero() {
  return (
    <div id="home" className="pt-16">
      <div className="relative bg-gradient-to-r from-blue-600 to-blue-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="text-white">
              <h1 className="text-4xl md:text-5xl font-bold leading-tight mb-6">
                Fast & Reliable Delivery Services
              </h1>
              <p className="text-xl mb-8">
                Your trusted partner in logistics. We deliver your packages safely and on time, anywhere in the world.
              </p>
              <div className="flex space-x-4">
                <button className="bg-white text-blue-600 px-6 py-3 rounded-md font-semibold hover:bg-gray-100 flex items-center">
                  Get Started <ArrowRight className="ml-2 h-5 w-5" />
                </button>
                <button className="border-2 border-white text-white px-6 py-3 rounded-md font-semibold hover:bg-white hover:text-blue-600">
                  Track Package
                </button>
              </div>
            </div>
            <div className="hidden md:block">
              <img 
                src="https://images.unsplash.com/photo-1566576912321-d58ddd7a6088?auto=format&fit=crop&q=80"
                alt="Delivery Service"
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>

        <div className="bg-white py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="flex items-center space-x-4">
                <Package className="h-12 w-12 text-blue-600" />
                <div>
                  <h3 className="text-xl font-semibold">Secure Packaging</h3>
                  <p className="text-gray-600">Your items are handled with care</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <Clock className="h-12 w-12 text-blue-600" />
                <div>
                  <h3 className="text-xl font-semibold">Express Delivery</h3>
                  <p className="text-gray-600">Fast and on-time delivery</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <Globe className="h-12 w-12 text-blue-600" />
                <div>
                  <h3 className="text-xl font-semibold">Global Coverage</h3>
                  <p className="text-gray-600">Delivering worldwide</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}