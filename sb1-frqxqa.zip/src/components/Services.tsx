import React from 'react';
import { Truck, Plane, Box, ShieldCheck } from 'lucide-react';

export default function Services() {
  const services = [
    {
      icon: <Truck className="h-12 w-12 text-blue-600" />,
      title: 'Ground Shipping',
      description: 'Reliable road delivery services for your local and interstate shipping needs.',
    },
    {
      icon: <Plane className="h-12 w-12 text-blue-600" />,
      title: 'Air Freight',
      description: 'Express air delivery services for time-sensitive shipments worldwide.',
    },
    {
      icon: <Box className="h-12 w-12 text-blue-600" />,
      title: 'Warehousing',
      description: 'Secure storage solutions with advanced inventory management.',
    },
    {
      icon: <ShieldCheck className="h-12 w-12 text-blue-600" />,
      title: 'Secure Delivery',
      description: 'End-to-end tracking and insurance for your valuable packages.',
    },
  ];

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Services</h2>
          <p className="text-xl text-gray-600">Comprehensive logistics solutions for all your needs</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
              <div className="mb-4">{service.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
              <p className="text-gray-600">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}